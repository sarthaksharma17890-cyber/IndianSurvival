using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 5f;
    public float gravity = -20f;
    public Transform cameraTransform;
    CharacterController controller;
    Vector3 velocity;
    Vector2 mobileInput;

    void Awake() { controller = GetComponent<CharacterController>(); }
    void Update()
    {
        Vector2 input = mobileInput;
        input += new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        input = Vector2.ClampMagnitude(input, 1f);
        Vector3 forward = cameraTransform ? cameraTransform.forward : transform.forward;
        Vector3 right = cameraTransform ? cameraTransform.right : transform.right;
        forward.y = 0; right.y = 0; forward.Normalize(); right.Normalize();
        Vector3 move = forward * input.y + right * input.x;
        if (move.sqrMagnitude > 0.01f)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(move), 12f * Time.deltaTime);
        }
        controller.Move(move * moveSpeed * Time.deltaTime);
        if (controller.isGrounded && velocity.y < 0) velocity.y = -2f;
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }
    public void MoveForward() => mobileInput.y = 1;
    public void MoveBackward() => mobileInput.y = -1;
    public void MoveLeft() => mobileInput.x = -1;
    public void MoveRight() => mobileInput.x = 1;
    public void StopVertical() => mobileInput.y = 0;
    public void StopHorizontal() => mobileInput.x = 0;
}
