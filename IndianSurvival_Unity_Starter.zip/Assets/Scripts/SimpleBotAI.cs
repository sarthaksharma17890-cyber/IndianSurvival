using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class SimpleBotAI : MonoBehaviour
{
    public Transform target;
    public float moveSpeed = 2.4f, attackRange = 18f, damage = 8f, fireInterval = 1.2f;
    CharacterController controller;
    float nextAttack;
    void Awake() { controller = GetComponent<CharacterController>(); }
    void Update()
    {
        if (!target) return;
        Vector3 delta = target.position - transform.position;
        delta.y = 0;
        if (delta.sqrMagnitude > attackRange * attackRange)
        {
            Vector3 dir = delta.normalized;
            controller.Move(dir * moveSpeed * Time.deltaTime);
            if (dir.sqrMagnitude > .01f) transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(dir), 6f * Time.deltaTime);
        }
        else if (Time.time >= nextAttack)
        {
            nextAttack = Time.time + fireInterval;
            Health h = target.GetComponent<Health>();
            if (h) h.TakeDamage(damage);
        }
    }
}
