using UnityEngine;

public class SafeZone : MonoBehaviour
{
    public Transform player;
    public float startRadius = 100f, endRadius = 12f, shrinkDuration = 300f;
    public float damagePerSecond = 5f;
    public float CurrentRadius { get; private set; }
    float elapsed;
    void Update()
    {
        elapsed += Time.deltaTime;
        CurrentRadius = Mathf.Lerp(startRadius, endRadius, Mathf.Clamp01(elapsed / shrinkDuration));
        if (player)
        {
            Vector3 a = player.position; a.y = 0;
            Vector3 c = transform.position; c.y = 0;
            if (Vector3.Distance(a, c) > CurrentRadius)
            {
                Health h = player.GetComponent<Health>();
                if (h) h.TakeDamage(damagePerSecond * Time.deltaTime);
            }
        }
    }
    void OnDrawGizmos()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, Application.isPlaying ? CurrentRadius : startRadius);
    }
}
