using UnityEngine;
using UnityEngine.Events;

public class Health : MonoBehaviour
{
    public float maxHealth = 100f;
    public UnityEvent onDeath;
    public float Current { get; private set; }
    void Awake() { Current = maxHealth; }
    public void TakeDamage(float amount)
    {
        if (Current <= 0) return;
        Current = Mathf.Max(0, Current - amount);
        if (Current <= 0) { onDeath?.Invoke(); Destroy(gameObject, 1.5f); }
    }
    public void Heal(float amount) { Current = Mathf.Min(maxHealth, Current + amount); }
}
