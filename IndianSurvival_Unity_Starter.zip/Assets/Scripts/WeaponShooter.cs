using UnityEngine;

public class WeaponShooter : MonoBehaviour
{
    public Camera aimCamera;
    public Transform firePoint;
    public float damage = 25f, range = 120f, fireRate = 8f;
    public int magazineSize = 30, ammoInMagazine = 30, reserveAmmo = 120;
    public ParticleSystem muzzleFlash;
    public AudioSource shotAudio;
    float nextShot;

    void Update()
    {
        if (Input.GetMouseButton(0)) Fire();
        if (Input.GetKeyDown(KeyCode.R)) Reload();
    }
    public void Fire()
    {
        if (Time.time < nextShot || ammoInMagazine <= 0) return;
        nextShot = Time.time + 1f / fireRate;
        ammoInMagazine--;
        if (muzzleFlash) muzzleFlash.Play();
        if (shotAudio) shotAudio.Play();
        Camera cam = aimCamera ? aimCamera : Camera.main;
        if (cam && Physics.Raycast(cam.transform.position, cam.transform.forward, out RaycastHit hit, range))
        {
            Health health = hit.collider.GetComponentInParent<Health>();
            if (health) health.TakeDamage(damage);
        }
    }
    public void Reload()
    {
        int needed = magazineSize - ammoInMagazine;
        int amount = Mathf.Min(needed, reserveAmmo);
        ammoInMagazine += amount;
        reserveAmmo -= amount;
    }
}
