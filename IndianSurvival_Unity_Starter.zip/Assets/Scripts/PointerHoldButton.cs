using UnityEngine;
using UnityEngine.EventSystems;

public class PointerHoldButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerExitHandler
{
    public PlayerController player;
    public enum Direction { Forward, Backward, Left, Right }
    public Direction direction;
    public void OnPointerDown(PointerEventData eventData)
    {
        if (!player) return;
        switch (direction)
        {
            case Direction.Forward: player.MoveForward(); break;
            case Direction.Backward: player.MoveBackward(); break;
            case Direction.Left: player.MoveLeft(); break;
            case Direction.Right: player.MoveRight(); break;
        }
    }
    public void OnPointerUp(PointerEventData eventData) { Stop(); }
    public void OnPointerExit(PointerEventData eventData) { Stop(); }
    void Stop()
    {
        if (!player) return;
        if (direction == Direction.Forward || direction == Direction.Backward) player.StopVertical();
        else player.StopHorizontal();
    }
}
