INDIAN SURVIVAL - UNITY 3D STARTER
=================================
Yeh ek playable prototype starter source hai, finished commercial game nahi.

IMPORTANT:
- Unity Editor ko Android phone par officially run nahi kar sakte. Unity Editor ke liye Windows/macOS/Linux computer chahiye.
- Unity Hub se Unity 6 LTS install karein aur Android Build Support (SDK, NDK, OpenJDK) select karein.
- Unity mein 3D (URP optional) project banayein.
- Is ZIP ke Assets folder ko project ke root mein copy karein.
- Scene mein Ground (Plane), Player (Capsule + CharacterController), Main Camera, Directional Light aur kuch Enemy Capsules banayein.
- Player par PlayerController.cs lagayein. Camera par ThirdPersonCamera.cs lagayein aur target Player set karein.
- Player ke child mein ek empty object "FirePoint" banayein (local position 0,1.2,0.5), WeaponShooter.cs player par lagayein, firePoint assign karein.
- Enemies par Health.cs aur SimpleBotAI.cs lagayein. Enemy ke paas CharacterController hona chahiye.
- SafeZone object par SafeZone.cs lagayein.
- Mobile controls ke liye Canvas + UI Buttons banakar OnClick mein PlayerController.MoveForward/MoveBackward/MoveLeft/MoveRight, WeaponShooter.Fire aur WeaponShooter.Reload connect karein.
- Mobile UI buttons ke liye pointer hold movement implement karne ke liye UI EventTrigger ya custom press/release component use karein.
- Weapon models, realistic human rigs, animations, terrain, audio, UI art, networking, matchmaking, anti-cheat aur backend alag se add karne honge.

CONTROLS:
Keyboard: WASD move, mouse aim, left click fire, R reload.
Mobile: UI buttons hook up karein.

PLAY STORE:
Android Build Settings/Build Profiles mein Android select karein, ARM64 enable karein, IL2CPP choose karein, keystore se signed AAB build karein. Play Console mein app listing, privacy/data safety, content rating, testing aur policy requirements complete karein. Publication guaranteed nahi hoti; Google review karta hai.

ASSETS:
Only use models/audio you own or have a commercial licence to use. Real weapon brand/model names and third-party game assets may have trademark/copyright restrictions. This starter uses Unity primitives and no third-party assets.
